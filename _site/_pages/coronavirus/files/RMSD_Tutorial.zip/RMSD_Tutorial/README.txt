For QUARK models RMSD calculations:
	Use the determined structure of human hemoglobin: 1si4.pdb

For SWISS models and Robetta models RMSD calculations: 
	Use the determined structure of SARS-CoV-2 Spike: 6vxx.pdb
	*Note that Robetta models predict only one chain of the Spike protein rather than the entire protein.

For Galaxy models RMSD calculations:
	Use the determined structure of SARS-CoV-2 Spike receptor binding domain: 6lzg.pdb